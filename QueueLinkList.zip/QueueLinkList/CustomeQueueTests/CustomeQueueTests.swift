//
//  CustomeQueueTests.swift
//  CustomeQueueTests
//
//  Created by Sushil Kumar Singh on 03/07/21.
//

import XCTest
@testable import CustomeQueue

class CustomeQueueTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    func testAdd1Queue(){
        let queue = Queue<Int>()
        queue.enqueue(newValue: 1)
        queue.enqueue(newValue: 2)
        queue.enqueue(newValue: 3)
        while queue.rear.next != nil {
            print("queue value:\(String(describing: queue.rear.value))")
            queue.rear = queue.rear.next!
            
        }
        XCTAssert(queue.isEmpty() == false,"data insterted" )

    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
